<link rel="stylesheet" href="<?php echo base_url(); ?>backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
<script src="<?php echo base_url(); ?>backend/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <?php  $this->load->view('layout/notification_link'); ?>
    
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <!-- left column -->
                <form id="form1" action="<?php echo base_url() ?>admin/notification/add"  id="employeeform" name="employeeform" method="post" accept-charset="utf-8">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><i class="fas fa-comment"></i> <?php echo $this->lang->line('compose_new_message'); ?></h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <?php if ($this->session->flashdata('msg')) { ?>
                                <?php echo $this->session->flashdata('msg') ?>
                            <?php } ?>
                                    <?php echo $this->customlib->getCSRF(); ?>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label for="exampleInputEmail1"><?php echo $this->lang->line('title'); ?></label>
                                    <input id="title" name="title" placeholder="" type="text" class="form-control"  value="<?php echo set_value('title'); ?>" />
                                    <span class="text-danger"><?php echo form_error('title'); ?></span>
                                </div>
                                <div class="form-group"><label><?php echo $this->lang->line('message'); ?></label>
                                    <textarea id="compose-textarea" name="message" class="form-control" style="height: 300px">
                                        <?php echo set_value('message'); ?>
                                    </textarea>
                                    <span class="text-danger"><?php echo form_error('message'); ?></span>
                                </div>

                            </div>
                            <div class="col-md-3">
                                <div class="box-body">
                                    <?php
                                    if (isset($error_message)) {
                                        echo "<div class='alert alert-danger'>" . $error_message . "</div>";
                                    }
                                    ?>    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1"><?php echo $this->lang->line('notice_date'); ?></label>
                                        <input id="date" name="date"  placeholder="" type="text" class="form-control date"  value="<?php echo set_value('date'); ?>" />
                                        <span class="text-danger"><?php echo form_error('date'); ?></span>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1"><?php echo $this->lang->line('publish_on'); ?></label>
                                        <input id="publish_date" name="publish_date"  placeholder="" type="text" class="form-control date"  value="<?php echo set_value('publish_date'); ?>" />
                                        <span class="text-danger"><?php echo form_error('publish_date'); ?></span>
                                    </div>
                                    <div class="form-horizontal">
                                        <label for="exampleInputEmail1"><?php echo $this->lang->line('message_to'); ?></label>
                                        <div class="checkbox">
                                            <label><input type="checkbox" name="visible[]" value="student" <?php echo set_checkbox('visible[]', 'student', false) ?> /> <b><?php echo $this->lang->line('student'); ?></b> </label>
                                        </div>
                                        <div class="checkbox">
                                            <label><input type="checkbox" name="visible[]"  value="parent" <?php echo set_checkbox('visible[]', 'parent', false) ?> /> <b><?php echo $this->lang->line('parent'); ?></b></label>
                                        </div>
                                        <div class="checkbox">
                                            <label><input type="checkbox" name="visible[]" value="teacher" <?php echo set_checkbox('visible[]', 'teacher', false) ?> /> <b><?php echo $this->lang->line('teacher'); ?></b> </label>
                                        </div>
                                    </div>
                                    <span class="text-danger"><?php echo form_error('visible[]'); ?></span>

                                </div>
                            </div>                          
                            <div class="box-footer">
                                <div class="pull-left">

                                    <button type="submit" style="margin-left:20px" class="btn btn-primary"><i class="far fa-envelope"></i> <?php echo $this->lang->line('send'); ?></button>
                                </div>
                            </div>                          
                        </div>                      
                    </div>
                </form>              
            </div>
        </div><!--./wrapper-->
        <div class="row">            
            <div class="col-md-12">
            </div><!--/.col (right) -->
        </div>   <!-- /.row -->
    </section><!-- /.content -->
</div>
<script type="text/javascript">
    $(document).ready(function () {
        var date_format = '<?php echo $result = strtr($this->customlib->getSchoolDateFormat(), ['d' => 'dd', 'm' => 'mm', 'Y' => 'yyyy',]) ?>';

        $('.date').datepicker({           
            format: date_format,
            autoclose: true
        });
        $("#btnreset").click(function () {           
            $("#form1")[0].reset();
        });

    });
</script>
<script>
    $(function () {       
        $("#compose-textarea").wysihtml5();
    });
</script>