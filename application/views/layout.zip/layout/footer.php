<?php
?>
<script src="<?php echo base_url(); ?>backend/dist/js/moment.min.js"></script>
<footer class="main-footer">



</footer>
<div class="control-sidebar-bg"></div>
</div>

<script>
    $.widget.bridge( 'uibutton', $.ui.button );
</script>
<link href="<?php echo base_url(); ?>backend/toast-alert/toastr.css" rel="stylesheet"/>
<script src="<?php echo base_url(); ?>backend/toast-alert/toastr.js"></script>
<script src="<?php echo base_url(); ?>backend/bootstrap/js/bootstrap.min.js"></script>

<script src="<?php echo base_url(); ?>backend/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<script src="<?php echo base_url(); ?>backend/dist/js/moment.min.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/slimScroll/jquery.slimscroll.min.js"></script>

<script src="<?php echo base_url(); ?>backend/plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>backend/plugins/fastclick/fastclick.min.js"></script>
<script src="<?php echo base_url(); ?>backend/select2/dist/js/select2.min.js"></script>
<script src="<?php echo base_url(); ?>backend/dist/js/app.js"></script>
<script type="text/javascript">
   $(document).ready(function() {
    $('#class_id').hide();       
    $('#class_id').select2();
    $('#section_id').hide();       
    $('#section_id').select2();
});
    $( document ).ready( function () {
   
        var table = $( '.example' ).DataTable();
        $( 'div.dataTables_filter input' ).attr( 'placeholder', 'Search...' );
        var table = $( '.example2' ).DataTable();
        $( 'div.dataTables_filter input' ).attr( 'placeholder', 'Search...' );
        var table = $( '.example3' ).DataTable();
        $( 'div.dataTables_filter input' ).attr( 'placeholder', 'Search...' );
        var table = $( '.example4' ).DataTable();
        $( 'div.dataTables_filter input' ).attr( 'placeholder', 'Search...' );
        var table = $( '.example5' ).DataTable();
        $( 'div.dataTables_filter input' ).attr( 'placeholder', 'Search...' );
    } );

</script>

<script type="text/javascript">
    jQuery( function ( $ ) {
        $( "input[type='number'][min=0]" ).change( function () {
            var val = $( this ).val();
            val = parseInt( val );
            if ( isNaN( val ) ) {
                val = "";
            } else if ( val < 0 ) {
                val = 0 - val;
            }

            $( this ).val( val );
        } );
    } );
    jQuery( function ( $ ) {
        $( '.balance_sheet_input_submit' ).keydown( function ( e ) {

            var url = $( this ).data( 'url' ),
                selectors = $( this ).data( 'values' );
                console.log(e.key);
            if ( e.key.toLowerCase() == 'enter' ) {
                e.preventDefault();
                var values = $( selectors ).serialize();
                console.log(values);
                console.log(url);
                window.location.href = url + "?" + values;
            }
        } );

        // on pressing enter submit the form
        $( ".on_enter_submit" ).on( 'keydown', function ( e ) {
            var form = $( this ).parents( 'form' );

            if ( e.key.toLowerCase() == 'enter' || e.keyCode == 13 ) {
                e.preventDefault();
                $( form ).submit();
            }
        } );
    } );
</script>

<!--print table-->
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/buttons.bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/jszip.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/pdfmake.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/buttons.colVis.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/buttons.flash.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/vfs_fonts.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/buttons.html5.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>backend/dist/jsdata/buttons.print.min.js"></script>


<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<style>
    .group {
        background-color: #e0e0e0;
    }
</style>
<script type="text/javascript">

$( document ).ready( function () {

        if ( $( '#active_student' ).length ) {
            var title = 'Active Students';
            var table  = $( '#active_student' );
            /* new addition changed parameters with grouping index (3) total columns (19) and unorderable column (18) */
            datatable_call(table,title, 3, 19, [18]);
          
        }
        if ( $( '#new_students' ).length ) {
            var title = 'New Students';
            var table  = $( '#new_students' );
            datatable_call(table,title);
        }
        if ( $( '#free_students' ).length ) {
            var title = 'Free Students';
            var table  = $( '#free_students' );
            datatable_call(table,title);
        }
        if ( $( '#adjusted' ).length ) {
            var title = currrnet_month()+' Advance Adjusted Students';
            var table  = $( '#adjusted' );
            datatable_call(table,title);
        }
        if ( $( '#voucher_wise_collection' ).length ) {
            var title = currrnet_month()+' Voucher Wise Fee Collection Report';
            var table  = $( '#voucher_wise_collection' );
            datatable_call(table,title);
        }
        if ( $( '#student_wise_collection' ).length ) {
            var title = currrnet_month()+' Student Wise Fee Collection Report';
            var table  = $( '#student_wise_collection' );
            datatable_call(table,title);
        }  
        if ( $( '#unpaid_voucher' ).length ) {
            var title = currrnet_month()+' Unpaid Voucher';
            var table  = $( '#unpaid_voucher' );
            datatable_call(table,title);
        }  

        if ( $( '#waive_reports' ).length ) {
            var title = currrnet_month()+' Voucher Wise Fee Waived Report';
            var table  = $( '#waive_reports' );
            datatable_call(table,title);
        }  
        if ( $( '#student_wise_waive' ).length ) {
            var title = currrnet_month()+' Student Wise Fee Waived Report';
            var table  = $( '#student_wise_waive' );
            datatable_call(table,title);
        }  

        if ( $( '#withdraw_students' ).length ) {
            var title = currrnet_month()+' Struck Off Students Reports';
            var table  = $( '#withdraw_students' );
            datatable_call(table,title);
        }  
        if ( $( '#due_reports' ).length ) {
            var title = currrnet_month()+' Due Fee Reports';
            var table  = $( '#due_reports' );
            datatable_call(table,title);
        }  
        if ( $( '#student_wise_unpaid' ).length ) {
            var title = currrnet_month()+' Due Fee Reports';
            var table  = $( '#student_wise_unpaid' );
            datatable_call(table,title);
        }  
        if ( $( '#paid_other_fee' ).length ) {
            var title = currrnet_month()+' Paid Voucher (Other Fee)';
            var table  = $( '#paid_other_fee' );
            datatable_call(table,title);
        }
        if ( $( '#message_tuition' ).length ) {
            var title = currrnet_month()+' Message Tuition Unpaid Fee Reports';
            var table  = $( '#message_tuition' );
            datatable_call(table,title);
        }
        if ( $( '#message_other' ).length ) {
            var title = currrnet_month()+' Message Tuition Unpaid Fee Reports';
            var table  = $( '#message_other' );
            datatable_call(table,title);
        }
function currrnet_month(){

    var month = new Array();
    month[0] = "January";
    month[1] = "February";
    month[2] = "March";
    month[3] = "April";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "August";
    month[8] = "September";
    month[9] = "October";
    month[10] = "November";
    month[11] = "December";

    var d = new Date();
    var n = month[d.getMonth()];
    return n;
}
        
        $('.grid tbody').on('click', 'tr.group', function () {
            var currentOrder = table.order()[0];
            if (currentOrder[0] === 0 && currentOrder[1] === 'asc') {
                table.order([0, 'desc']).draw();
            } else {
                table.order([0, 'asc']).draw();
            }
        });


        /* new addition changed parameters & added condition block, compare with older one... you'll see difference...  */
        function datatable_call(tablee,title , groupCol=0, totalCols=0,  UnOrderAble=[]){

            if(groupCol >0){
                
                 var table = tablee.not('.initialized').addClass('initialized').show().DataTable( {
                     destroy: true,
                    fixedHeader: {
                        header: true,
                        footer: true,
                        headerOffset: $('.main-header').outerHeight()
                    },

                    "stateSave": false,
                    "stateDuration": 60 * 60 * 24 * 365,
                    "displayLength": 100,
                    "sScrollX": "100%",
                    
                    // "scrollY":        "300px",
                        // "scrollCollapse": true,
                        
                    order: [[groupCol, 'asc']],
                    // drawCallback: function (settings) {
                    //     var api = this.api();
                    //     var rows = api.rows({page: 'current'}).nodes();
                    //     var last = null;
        
                    //     api.column(groupCol, {page: 'current'}).data().each(function (group, i) {
                    //         if (last !== group) {
                    //             $(rows).eq(i).before(
                    //                 '<tr class="group"><td colspan="' + totalCols + '">' + group + '</td></tr>',
                    //             );
                    //             last = group;
                    //         }
                    //     });
                    // },
                    
                    "drawCallback": function (settings) {
                        var api = this.api();
                        var rows = api.rows({page: 'current'}).nodes();
                        var last = null;
                        var colonne = api.row(groupCol).data().length;
                        var totale = new Array();
                        totale['Totale'] = new Array();
                        var groupid = -1;
                        var subtotale = new Array();
        
                        api.column(groupCol, {page: 'current'}).data().each(function (group, i) {
                            if (last !== group) {
                                groupid++;
                                $(rows).eq(i).before(
                                    '<tr class="group"><td>' + group + '</td></tr>'
                                );
                                last = group;
                            }
        
        
                            val = api.row(api.row($(rows).eq(i)).index()).data();      //current order index
                            $.each(val, function (index2, val2) {
                                if (typeof subtotale[groupid] == 'undefined') {
                                    subtotale[groupid] = new Array();
                                }
                                if (typeof subtotale[groupid][index2] == 'undefined') {
                                    subtotale[groupid][index2] = 0;
                                }
                                if (typeof totale['Totale'][index2] == 'undefined') {
                                    totale['Totale'][index2] = 0;
                                }
        
                                valore = Number(val2.replace('€', "").replace(',', ""));
                                subtotale[groupid][index2] += valore;
                                totale['Totale'][index2] += valore;
                            });
        
        
                        });
                        $('tbody').find('.group').each(function (i, v) {
                            var rowCount = $(this).nextUntil('.group').length;
                            $(this).find('td:first').append($('<span />', {'class': 'rowCount-grid'}).append($('<b />', {'text': ' (' + rowCount + ')'})));
                            var subtd = '';
                            for (var a = 2; a < colonne; a++) {
                                var mySubtotal = "";
        
                                // allow columns only of index 10 to 17
                                if (a>=10 && a<=17) {
                                    mySubtotal = $.fn.dataTable.render.number(',', '.', 0, '').display(subtotale[i][a]);
                                }
        
                                subtd += '<td class="text-center">' + mySubtotal + '' + '</td>';
        
                                // subtd += '<td>' + subtotale[i][a] + ' OUT OF ' + totale['Totale'][a] + ' (' + Math.round(subtotale[i][a] * 100 / totale['Totale'][a], 2) + '%) ' + '</td>';
                            }
                            $(this).append(subtd);
                        });
        
                    },
                   
                    columnDefs: [
                      { orderable: false },
                       {
                            targets: UnOrderAble,
                            orderable: false
                        },
                        {
                            targets: groupCol,
                            visible: false,
                        },
                   ]
                    
                    
                    
                }
                );
                        
                        
            } else {
                
                var table = tablee.DataTable( {
                        "scrollY":        "300px",
                        "scrollCollapse": true,
                    });
                        
            }
                        
                        

                new $.fn.dataTable.Buttons( table, {
                   buttons: [
                       {
                           extend: 'copyHtml5',
                           text: '<i class="fa fa-files-o"></i>',
                           titleAttr: 'Copy',
                           exportOptions: {
                               columns: ':visible'
                           }
                       },
                       {
                           extend: 'excelHtml5',
                           text: '<i class="fa fa-file-excel-o"></i>',
                           titleAttr: 'Excel',
                           exportOptions: {
                               columns: ':visible'
                           }
                       },
                       {
                           extend: 'csvHtml5',
                           text: '<i class="fas fa-file-csv"></i>',
                           titleAttr: 'CSV',
                           exportOptions: {
                               columns: ':visible'
                           }
                       },
    
                       {
                           extend: 'pdfHtml5',
                           text: '<i class="fa fa-file-pdf-o"></i>',
                           titleAttr: 'PDF',
                           exportOptions: {
                               columns: ':visible'
                           }
                       },
                       {
                           extend: 'print',
                           customize: function ( win ) {
                               $(win.document.body)
                               .css( 'font-size', '12pt' )
                                   
                               $(win.document.body).find( 'table' )
                                   .addClass( 'compact' )
                                   .css( 'font-size', 'inherit' );
                           },
                           text: '<i class="fa fa-print"></i>',
                           title: title,
                           titleAttr: 'Print',
                           exportOptions: {
                               columns: ':visible'
                           }
                       },
                       {
                           extend: 'colvis',
                           text: '<i class="fa fa-columns"></i>',
                           titleAttr: 'Columns',
                           postfixButtons: ['colvisRestore']
                       },
                    ],
               
                   
               
                } );
                
                // new $.fn.dataTable.FixedHeader( table, {
                //     footer: true,
                //     header: true,
                //     headerOffset: $('.main-header').outerHeight()
                // } );
                
                
           table.buttons( 0, null ).container().prependTo(
               table.table().container()
           );
        }



        var title = '<div style="font-size:21px;"><?php echo $print_title ?></div>';
        if ( $( '.example' ).length ) {
            var table = $( '.example' ).DataTable();
            
            new $.fn.dataTable.Buttons( table, {
               
                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fa fa-files-o"></i>',
                        titleAttr: 'Copy',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel-o"></i>',
                        titleAttr: 'Excel',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fas fa-file-csv"></i>',
                        titleAttr: 'CSV',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf-o"></i>',
                        titleAttr: 'PDF',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'print',
                        customize: function ( win ) {
                            $(win.document.body)
                            .css( 'font-size', '12pt' )
                                
                            $(win.document.body).find( 'table' )
                                .addClass( 'compact' )
                                .css( 'font-size', 'inherit' );
                        },
                        text: '<i class="fa fa-print"></i>',
                        title: title,
                        titleAttr: 'Print',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },


                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        postfixButtons: ['colvisRestore']
                    },


                ],
                columnDefs: [
                    { orderable: false }
                ]
            } );

            table.buttons( 0, null ).container().prependTo(
                table.table().container()
            );
        }
    } );
</script>
<script type="text/javascript">

$( document ).ready( function () {




        var title = '<div style="font-size:21px;"><?php echo $print_title ?></div>';
        if ( $( '#example' ).length ) {
            var table = $( '#example' ).DataTable( {
                            "order": [],
                            // "scrollY":        "500px",
                            // "scrollCollapse": true,
                            fixedHeader: {
                                header: true,
                                footer: true,
                                headerOffset: $('.main-header').outerHeight()
                            },
                            "paging":         false,
                            // fixedHeader: true
                        });
        
            new $.fn.dataTable.Buttons( table, {
               
                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fa fa-files-o"></i>',
                        titleAttr: 'Copy',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel-o"></i>',
                        titleAttr: 'Excel',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fas fa-file-csv"></i>',
                        titleAttr: 'CSV',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf-o"></i>',
                        titleAttr: 'PDF',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'print',
                        customize: function ( win ) {
                            $(win.document.body)
                            .css( 'font-size', '12pt' )
                                
                            $(win.document.body).find( 'table' )
                                .addClass( 'compact' )
                                .css( 'font-size', 'inherit' );
                        },
                        text: '<i class="fa fa-print"></i>',
                        title: title,
                        titleAttr: 'Print',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },


                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        postfixButtons: ['colvisRestore']
                    },


                ],
                columnDefs: [
                    { orderable: false }
                ]
            } );


            table.buttons( 0, null ).container().prependTo(
                table.table().container()
            );
        }
    } );
</script>
<script type="text/javascript">
    $( document ).ready( function () {
        var title = '<div style="font-size:21px;"><?php echo $print_title_2 ?></div>';
        if ( $( '.example_print' ).length ) {
            var table = $( '.example_print' ).DataTable();
            new $.fn.dataTable.Buttons( table, {

                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fa fa-files-o"></i>',
                        titleAttr: 'Copy',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel-o"></i>',
                        titleAttr: 'Excel',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fas fa-file-csv"></i>',
                        titleAttr: 'CSV',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf-o"></i>',
                        titleAttr: 'PDF',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'print',
                        customize: function ( win ) {
                            $(win.document.body)
                            .css( 'font-size', '12pt' )
                                
                            $(win.document.body).find( 'table' )
                                .addClass( 'compact' )
                                .css( 'font-size', 'inherit' );
                        },
                        text: '<i class="fa fa-print"></i>',
                        title: title,
                        titleAttr: 'Print',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },


                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        postfixButtons: ['colvisRestore']
                    },


                ]
            } );

            table.buttons( 0, null ).container().prependTo(
                table.table().container()
            );
        }
    } );
</script>

<script type="text/javascript">
    $( document ).ready( function () {
        var title = '<div style="font-size:21px;"><?php echo $print_title ?></div>';
        
        if ( $( '.example2' ).length > 0 ) {

            var table = $( '.example2' ).DataTable();
            new $.fn.dataTable.Buttons( table, {

                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fa fa-files-o"></i>',
                        titleAttr: 'Copy',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel-o"></i>',
                        titleAttr: 'Excel',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fas fa-file-csv"></i>',
                        titleAttr: 'CSV',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf-o"></i>',
                        titleAttr: 'PDF',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'print',
                        customize: function ( win ) {
                            $(win.document.body)
                            .css( 'font-size', '12pt' )
                                
                            $(win.document.body).find( 'table' )
                                .addClass( 'compact' )
                                .css( 'font-size', 'inherit' );
                        },
                        title: title,
                        text: '<i class="fa fa-print"></i>',
                        titleAttr: 'Print',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },


                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        postfixButtons: ['colvisRestore']
                    },


                ]
            } );

            table.buttons( 0, null ).container().prependTo(
                table.table().container()
            );

        }

    } );
</script>
<script type="text/javascript">
    $( document ).ready( function () {

        if ( $( '.example3' ).length > 0 ) {

            var table = $( '.example3' ).DataTable();
            new $.fn.dataTable.Buttons( table, {

                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fa fa-files-o"></i>',
                        titleAttr: 'Copy',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel-o"></i>',
                        titleAttr: 'Excel',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fas fa-file-csv"></i>',
                        titleAttr: 'CSV',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf-o"></i>',
                        titleAttr: 'PDF',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'print',
                        text: '<i class="fa fa-print"></i>',
                        titleAttr: 'Print',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },


                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        postfixButtons: ['colvisRestore']
                    },


                ]
            } );

            table.buttons( 0, null ).container().prependTo(
                table.table().container()
            );

        }

    } );
</script>

<script type="text/javascript">
    $( document ).ready( function () {

        if ( $( '.example4' ).length > 0 ) {

            var table = $( '.example4' ).DataTable();
            new $.fn.dataTable.Buttons( table, {

                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fa fa-files-o"></i>',
                        titleAttr: 'Copy',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel-o"></i>',
                        titleAttr: 'Excel',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fas fa-file-spreadsheet"></i>',
                        titleAttr: 'CSV',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf-o"></i>',
                        titleAttr: 'PDF',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'print',
                        text: '<i class="fa fa-print"></i>',
                        titleAttr: 'Print',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },


                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        postfixButtons: ['colvisRestore']
                    },


                ]
            } );

            table.buttons( 0, null ).container().prependTo(
                table.table().container()
            );

        }

    } );
</script>

<script type="text/javascript">
    $( document ).ready( function () {

        if ( $( '.example5' ).length > 0 ) {

            var table = $( '.example5' ).DataTable();
            new $.fn.dataTable.Buttons( table, {

                buttons: [

                    {
                        extend: 'copyHtml5',
                        text: '<i class="fa fa-files-o"></i>',
                        titleAttr: 'Copy',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'excelHtml5',
                        text: '<i class="fa fa-file-excel-o"></i>',
                        titleAttr: 'Excel',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'csvHtml5',
                        text: '<i class="fas fa-file-spreadsheet"></i>',
                        titleAttr: 'CSV',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'pdfHtml5',
                        text: '<i class="fa fa-file-pdf-o"></i>',
                        titleAttr: 'PDF',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },

                    {
                        extend: 'print',
                        text: '<i class="fa fa-print"></i>',
                        titleAttr: 'Print',
                        exportOptions: {
                            columns: ':visible'
                        }
                    },


                    {
                        extend: 'colvis',
                        text: '<i class="fa fa-columns"></i>',
                        titleAttr: 'Columns',
                        postfixButtons: ['colvisRestore']
                    },


                ]
            } );

            table.buttons( 0, null ).container().prependTo(
                table.table().container()
            );

        }

    } );
</script>
<script src="<?php echo base_url(); ?>backend/sweet-alert/sweetalert2.min.js"></script>
<script src="<?php echo base_url(); ?>backend/js/school-custom.js"></script>


<script type="text/javascript">
    $( document ).ready( function () {
        <?php


        if($this->session->flashdata( 'success_msg' )){
        ?>
        successMsg( "<?php echo $this->session->flashdata( 'success_msg' ); ?>" );
        <?php
        }else if($this->session->flashdata( 'error_msg' )){
        ?>
        errorMsg( "<?php echo $this->session->flashdata( 'error_msg' ); ?>" );
        <?php
        }else if($this->session->flashdata( 'warning_msg' )){
        ?>
        infoMsg( "<?php echo $this->session->flashdata( 'warning_msg' ); ?>" );
        <?php
        }else if($this->session->flashdata( 'info_msg' )){
        ?>
        warningMsg( "<?php echo $this->session->flashdata( 'info_msg' ); ?>" );
        <?php
        }
        ?>
    } );
</script>


<script type="text/javascript">
    jQuery( function ( $ ) {
        $( "body" ).keydown( function ( event ) {
            if ( event.ctrlKey === true && event.key.toLowerCase() == 'e' ) {
                event.preventDefault();

                window.location.href = "<?= site_url( 'admin/expense' ) ?>";
            }
        } );

        $( ".back_btn" ).click( function ( e ) {
            e.preventDefault();

            window.history.back();
        } );
    } );
</script>

<script type="text/javascript">
    jQuery( function ( $ ) {
        var date_format = 'mm/dd/yyyy';

        $( '._date' ).datepicker( {
            //  format: "dd-mm-yyyy",
            format: date_format,
            autoclose: true
        } );

    } );

    // function jquery_alert(message, type){
    //     if(type == undefined) type = 'success';
    //     $.alert({
    //         title: type=='success'?"Success!":"Error!",
    //         content: message
    //     });
    // }

</script>


<!--./print table-->
</body>
</html>